import { showHomeView } from "./home.js";
import "./nav.js";



showHomeView();